# BipartitenessInGraphsJS
Checks bipartiteness of a given graph.

Author: Marco Manigrasso

# INSTRUCTIONS
Drag and drop the index.html file into your browser and click on "Check!".

You can change the adjancency matrix ("Graph") to change which vertices are connected.
If you change the number of vertices in the matrix, you must also change the constant NUM_OF_VERTICES.